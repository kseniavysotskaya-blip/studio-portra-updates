#!/usr/bin/env python3
"""Studio Portra — local-only lighting setup journal; Canon EOS Utility folder watcher."""
from __future__ import annotations
import json, os, uuid, mimetypes, subprocess, sys, threading, time, webbrowser, secrets, shutil, hashlib
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse, parse_qs, quote
import release_manager as releases

ROOT = Path(__file__).resolve().parent
# Data live outside the app folder; subsequent code-only updates cannot replace them.
if sys.platform == 'darwin':
    DATA = Path.home() / 'Library' / 'Application Support' / 'Studio Portra' / 'mes-donnees'
else:
    DATA = Path(os.environ.get('XDG_DATA_HOME') or (Path.home() / '.local' / 'share')) / 'studio-portra' / 'mes-donnees'
LEGACY_DATA = ROOT / 'mes-donnees'
if LEGACY_DATA.is_dir() and not DATA.exists():
    shutil.copytree(LEGACY_DATA, DATA)  # copy without removing originals
DATA.mkdir(parents=True, exist_ok=True)
UPDATE_SETTINGS = DATA / 'mises-a-jour.json'
UPDATE_TOKEN = secrets.token_urlsafe(32)
APP_VERSION = releases.current_version(ROOT)

UPLOADS = DATA / 'photos-importees'
STATE_FILE = DATA / 'projet.json'
UPLOADS.mkdir(parents=True, exist_ok=True)
RAW_EXTENSIONS = {'.cr3'}
VALID_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp'} | RAW_EXTENSIONS
PREVIEWS = DATA / 'apercus-raw'
PREVIEWS.mkdir(parents=True, exist_ok=True)
PREVIEW_LOCK = threading.Lock()
PREVIEW_FAILURES = {}
LOCK = threading.RLock()
UPDATE_LOCK = threading.Lock()

def update_preferences():
    try:
        val=json.loads(UPDATE_SETTINGS.read_text(encoding='utf-8'))
        return {'source':str(val.get('source') or '')[:2000], 'automatic':bool(val.get('automatic',True))}
    except (ValueError, OSError, TypeError):
        return {'source':'', 'automatic':True}

def save_update_preferences(data):
    temp=UPDATE_SETTINGS.with_suffix('.tmp')
    temp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    temp.replace(UPDATE_SETTINGS)


def restart_after_update():
    # The current process continues just long enough to acknowledge the request;
    # exec replaces it, and the same port is reused by the next process.
    time.sleep(1.0)
    os.environ['STUDIO_PORTRA_PORT']=str(SERVER_PORT)
    os.environ['STUDIO_PORTRA_RESTART']='1'
    os.execv(sys.executable, [sys.executable, str(ROOT/'server.py')])



def setup_initial():
    return {
        'id': 'essai-1', 'schemaVersion': 3, 'name': '01 · Premier test Portra 400', 'date': datetime.now().strftime('%Y-%m-%d'),
        'background': {'name':'Polar White', 'color':'#f4f2e6', 'floorLength': 2},
        'subject': {'x':50, 'y':47}, 'camera': {'x':50,'y':86},
        'lights': [
            {'id':'flash-1', 'type':'hilite', 'name':'Lastolite HiLite 1,80 m', 'flash':'Elinchrom Pro HD', 'power':'2.0', 'trigger':'Radio / maître', 'x':25,'y':48,'angle':0,'lengthCm':180,'depthCm':49},
            {'id':'flash-2', 'type':'lantern', 'name':'Lanterne chinoise Ø 85 cm', 'flash':'Godox', 'power':'', 'trigger':'Esclave optique', 'x':82,'y':49,'angle':0,'diameterCm':85}
        ],
        'digital': {'model':'Canon EOS R6 Mark II', 'iso':'400', 'shutter':'1/60', 'aperture':'2.8', 'lens':'', 'wb':'Flash / 5500 K'},
        'film': {'model':'Pentax 645NII', 'film':'Kodak Portra 400 · 120', 'iso':'400', 'shutter':'1/60 (X)', 'aperture':'2.8', 'lens':''},
        'digitalPhoto':'', 'filmPhoto':'', 'notes':'',
    }


def initial_state():
    first=setup_initial()
    return {'watchFolder':'', 'activeId':first['id'], 'setups':[first]}


def load_state():
    with LOCK:
        if not STATE_FILE.exists():
            state=initial_state(); write_state(state); return state
        try:
            val=json.loads(STATE_FILE.read_text(encoding='utf-8'))
            if isinstance(val,dict) and isinstance(val.get('setups'),list): return val
        except (OSError,ValueError): pass
        return initial_state()


def write_state(state):
    with LOCK:
        temp=STATE_FILE.with_suffix('.tmp')
        temp.write_text(json.dumps(state, ensure_ascii=False, indent=2),encoding='utf-8')
        temp.replace(STATE_FILE)


def json_bytes(payload): return json.dumps(payload,ensure_ascii=False).encode('utf-8')


def media_path(url):
    if not isinstance(url,str): raise ValueError('Fichier non valide')
    if url.startswith('/captures/'):
        value=load_state().get('watchFolder','').strip()
        if not value: raise ValueError('Dossier Canon non configuré')
        base=Path(value).expanduser().resolve();name=unquote(url[len('/captures/'):])
    elif url.startswith('/imports/'):
        base=UPLOADS.resolve();name=unquote(url[len('/imports/'):])
        if name!=Path(name).name: raise ValueError('Nom invalide')
    else: raise ValueError('Fichier non valide')
    target=(base/name).resolve();target.relative_to(base)
    if not target.is_file() or target.suffix.lower() not in VALID_EXTENSIONS: raise ValueError('Fichier non pris en charge')
    return target

def raw_preview(src):
    st=src.stat()
    if st.st_size==0 or (src.parent.resolve()!=UPLOADS.resolve() and time.time()-st.st_mtime<1.5): raise ValueError('Transfert en cours')
    key=hashlib.sha256((str(src.resolve())+str(st.st_mtime_ns)+str(st.st_size)).encode()).hexdigest()
    dest=PREVIEWS/(key+'.jpg')
    with PREVIEW_LOCK:
        if dest.is_file(): return dest
        if time.time()-PREVIEW_FAILURES.get(key,0)<30: raise ValueError('Aperçu indisponible')
        tmp=PREVIEWS/(key+'-'+uuid.uuid4().hex+'.jpg')
        try:
            result=subprocess.run(['/usr/bin/sips','-s','format','jpeg','-Z','1600',str(src),'--out',str(tmp)],capture_output=True,timeout=45)
            after=src.stat()
            if (after.st_size,after.st_mtime_ns)!=(st.st_size,st.st_mtime_ns): raise ValueError('Transfert en cours')
            if result.returncode or not tmp.is_file() or not tmp.read_bytes().startswith(b'\xff\xd8'): raise ValueError('Aperçu non disponible pour ce RAW')
            tmp.replace(dest);return dest
        except Exception:
            PREVIEW_FAILURES[key]=time.time();raise
        finally:
            tmp.unlink(missing_ok=True)

def import_media(src,filename=None):
    st=src.stat()
    if st.st_size>120*1024*1024: raise ValueError('Fichier trop volumineux (120 Mo maximum)')
    if not st.st_size: raise ValueError('Fichier vide')
    raw=src.read_bytes();after=src.stat()
    if (st.st_size,st.st_mtime_ns)!=(after.st_size,after.st_mtime_ns): raise ValueError('Transfert en cours, réessaie dans un instant')
    return store_media(raw,src.suffix.lower(),filename or src.name)

def validate_cr3(raw):
    # A CR3 is a sequence of sized ISO media boxes. Reject truncated transfers.
    offset=0;has_ftyp=False;has_mdat=False
    while offset<len(raw):
        if offset+8>len(raw): raise ValueError('RAW incomplet, transfert en cours')
        size=int.from_bytes(raw[offset:offset+4],'big');kind=raw[offset+4:offset+8];header=8
        if size==1:
            if offset+16>len(raw): raise ValueError('RAW incomplet, transfert en cours')
            size=int.from_bytes(raw[offset+8:offset+16],'big');header=16
        if size==0: size=len(raw)-offset
        if size<header or offset+size>len(raw): raise ValueError('RAW incomplet, transfert en cours')
        has_ftyp=has_ftyp or kind==b'ftyp';has_mdat=has_mdat or kind==b'mdat'
        offset+=size
    if not has_ftyp or not has_mdat: raise ValueError('Fichier CR3 non reconnu ou incomplet')

def store_media(raw,ext,filename):
    if ext not in VALID_EXTENSIONS: raise ValueError('Format non pris en charge')
    if ext in RAW_EXTENSIONS: validate_cr3(raw)
    digest=hashlib.sha256(raw).hexdigest();target=UPLOADS/(digest+ext)
    if not target.exists():
        tmp=UPLOADS/(digest+'-'+uuid.uuid4().hex+'.tmp')
        try: tmp.write_bytes(raw);tmp.replace(target)
        finally: tmp.unlink(missing_ok=True)
    if hashlib.sha256(target.read_bytes()).hexdigest()!=digest: raise ValueError('Échec de vérification de la copie')
    original='/imports/'+quote(target.name);is_raw=ext in RAW_EXTENSIONS
    return {'url':'/raw-preview'+original if is_raw else original,'originalUrl':original,'filename':filename,'sha256':digest,'isRaw':is_raw}


class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args):
        if not self.path.startswith('/api/photos'): super().log_message(fmt,*args)

    def answer(self,code,payload):
        raw=json_bytes(payload)
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(raw)

    def blob(self,filepath, content_type=None):
        try:
            raw=Path(filepath).read_bytes()
            self.send_response(200)
            self.send_header('Content-Type',content_type or mimetypes.guess_type(str(filepath))[0] or 'application/octet-stream')
            self.send_header('Content-Length',str(len(raw)))
            self.send_header('Cache-Control','no-store')
            self.end_headers(); self.wfile.write(raw)
        except OSError: self.answer(404,{'error':'Fichier introuvable'})

    def update_auth(self):
        host=self.headers.get('Host','')
        origin=self.headers.get('Origin','')
        if host not in (f'127.0.0.1:{SERVER_PORT}', f'localhost:{SERVER_PORT}'):
            return False
        if origin and origin not in (f'http://127.0.0.1:{SERVER_PORT}', f'http://localhost:{SERVER_PORT}'):
            return False
        return secrets.compare_digest(self.headers.get('X-Studio-Token',''), UPDATE_TOKEN)

    def do_GET(self):
        route=urlparse(self.path).path
        if route=='/api/update/info':
            return self.answer(200,{'version':APP_VERSION,'token':UPDATE_TOKEN,
                'source':update_preferences()['source'],'auto':update_preferences()['automatic'],'dataDirectory':str(DATA),
                'canInstall':os.access(ROOT, os.W_OK)})
        if route=='/': return self.blob(ROOT/'index.html','text/html; charset=utf-8')
        if route=='/api/state': return self.answer(200,load_state())
        if route=='/api/photos':
            folder_value=load_state().get('watchFolder','').strip()
            folder=Path(folder_value).expanduser()
            if not folder_value or not folder.is_dir(): return self.answer(200,{'files':[],'folderValid':False})
            try:
                entries=[];observed=[]
                for f in folder.rglob('*'):
                    if f.is_file() and f.suffix.lower() in VALID_EXTENSIONS:
                        try:
                            f.resolve().relative_to(folder.resolve())
                            st=f.stat()
                            ready=st.st_size>0 and time.time()-st.st_mtime>=1.5
                            rel=f.relative_to(folder).as_posix()
                            entry={'name':rel,'id':f'{rel}:{st.st_mtime_ns}:{st.st_size}', 'url':'/captures/'+quote(rel, safe='/'), 'timestamp':st.st_mtime,'isRaw':f.suffix.lower() in RAW_EXTENSIONS,'previewUrl':('/raw-preview' if f.suffix.lower() in RAW_EXTENSIONS else '')+'/captures/'+quote(rel,safe='/'),'ready':ready}
                            observed.append(entry)
                            if ready: entries.append(entry)
                        except (OSError, ValueError): continue
                entries.sort(key=lambda x:x['timestamp'],reverse=True)
                return self.answer(200,{'files':entries[:100],'observed':observed,'folder':folder_value,'folderValid':True})
            except OSError as e: return self.answer(200,{'files':[],'folderValid':False,'error':str(e)})
        if route.startswith('/raw-preview/'):
            try:
                src=media_path(route[len('/raw-preview'):])
                if src.suffix.lower() not in RAW_EXTENSIONS: raise ValueError('RAW attendu')
            except (OSError,ValueError): return self.answer(404,{'error':'RAW introuvable'})
            try: return self.blob(raw_preview(src),'image/jpeg')
            except Exception:
                raw=b'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="260"><rect width="400" height="260" fill="#eef1eb"/><text x="200" y="120" text-anchor="middle" fill="#46584b" font-size="24">RAW</text><text x="200" y="155" text-anchor="middle" fill="#46584b" font-size="16">Apercu indisponible</text></svg>'
                self.send_response(200);self.send_header('Content-Type','image/svg+xml');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();return self.wfile.write(raw)
        if route.startswith('/captures/'):
            name=unquote(route[len('/captures/'):])
            if Path(name).suffix.lower() not in VALID_EXTENSIONS: return self.answer(400,{'error':'Nom invalide'})
            folder_value=load_state().get('watchFolder','').strip()
            folder=Path(folder_value).expanduser()
            if not folder_value or not folder.is_dir(): return self.answer(404,{'error':'Dossier introuvable'})
            try:
                target=(folder/name).resolve()
                target.relative_to(folder.resolve())
            except ValueError: return self.answer(403,{'error':'Accès interdit'})
            return self.blob(target)
        if route.startswith('/imports/'):
            name=unquote(route[len('/imports/'):])
            if name != Path(name).name or Path(name).suffix.lower() not in VALID_EXTENSIONS: return self.answer(400,{'error':'Nom invalide'})
            return self.blob(UPLOADS/name)
        if route=='/api/pick-folder':
            if sys.platform!='darwin': return self.answer(400,{'error':'Sélection native disponible sur macOS uniquement'})
            try:
                p=subprocess.run(['osascript','-e','POSIX path of (choose folder with prompt "Choisir le dossier où EOS Utility enregistre les photos")'],capture_output=True,text=True,timeout=120)
                if p.returncode or not p.stdout.strip(): return self.answer(400,{'error':'Sélection annulée'})
                return self.answer(200,{'path':p.stdout.strip()})
            except Exception as e: return self.answer(500,{'error':str(e)})
        self.answer(404,{'error':'Route inconnue'})

    def do_POST(self):
        # Reject cross-site writes. Local WKWebView is served by this same origin.
        supplied_origin=self.headers.get('Origin','')
        allowed={f'http://127.0.0.1:{SERVER_PORT}', f'http://localhost:{SERVER_PORT}'}
        if supplied_origin and supplied_origin not in allowed:
            return self.answer(403,{'error':'Origine non autorisée.'})
        host=self.headers.get('Host','')
        if host not in (f'127.0.0.1:{SERVER_PORT}',f'localhost:{SERVER_PORT}'):
            return self.answer(403,{'error':'Hôte non autorisé.'})
        route=urlparse(self.path).path
        if route.startswith('/api/update/') and not self.update_auth():
            return self.answer(403,{'error':'Accès à la mise à jour refusé.'})
        try:length=int(self.headers.get('Content-Length') or 0)
        except ValueError:return self.answer(400,{'error':'Taille de requête invalide.'})
        if length < 0 or length > 120*1024*1024:
            return self.answer(413,{'error':'Fichier trop volumineux (120 Mo maximum)'})
        raw=self.rfile.read(length)
        if route.startswith('/api/update/'):
            return self.manage_update(route, raw)

        if route=='/api/state':
            try:
                state=json.loads(raw)
                if not isinstance(state,dict) or not isinstance(state.get('setups'),list) or len(state['setups'])>200: raise ValueError('Projet incorrect')
                folder=str(state.get('watchFolder','')).strip()
                if folder and not Path(folder).expanduser().is_dir(): return self.answer(400,{'error':'Le dossier surveillé n’existe pas sur ce Mac'})
                write_state(state)
                return self.answer(200,{'ok':True})
            except (ValueError,UnicodeError) as e: return self.answer(400,{'error':str(e)})
        if route=='/api/reveal-original':
            try:
                url=json.loads(raw).get('url','')
                if not isinstance(url,str) or not url.startswith('/imports/'): raise ValueError('Original non valide')
                src=media_path(url)
                if sys.platform!='darwin': raise ValueError('Finder disponible sur Mac uniquement')
                subprocess.run(['/usr/bin/open','-R',str(src)],check=True,timeout=15)
                return self.answer(200,{'ok':True})
            except Exception as ex: return self.answer(400,{'error':str(ex)})
        if route=='/api/attach-capture':
            try:
                url=json.loads(raw).get('url','')
                if not isinstance(url,str) or not url.startswith('/captures/'): raise ValueError('Capture non valide')
                src=media_path(url)
                if time.time()-src.stat().st_mtime<1.5: raise ValueError('Transfert en cours, réessaie dans un instant')
                return self.answer(200,import_media(src))
            except (ValueError,OSError,TypeError) as ex:return self.answer(400,{'error':str(ex)})
        if route=='/api/pick-image':
            if sys.platform!='darwin': return self.answer(400,{'error':'Sélection de fichier disponible sur Mac uniquement.'})
            try:
                # Native macOS file chooser: avoids WKWebView file-input limitations.
                script='POSIX path of (choose file with prompt "Choisir une photo RAW CR3, JPEG, PNG ou WebP" of type {"public.jpeg", "public.png", "org.webmproject.webp", "public.camera-raw-image", "com.canon.cr3-raw-image"})'
                p=subprocess.run(['osascript','-e',script],capture_output=True,text=True,timeout=120)
                if p.returncode or not p.stdout.strip():return self.answer(400,{'error':'Sélection annulée'})
                src=Path(p.stdout.strip()).expanduser().resolve()
                if not src.is_file() or src.suffix.lower() not in VALID_EXTENSIONS: return self.answer(400,{'error':'Fichier non pris en charge (CR3, JPG, PNG, WebP).'} )
                if src.stat().st_size>120*1024*1024:return self.answer(400,{'error':'Fichier trop volumineux (120 Mo maximum).'})
                return self.answer(200,import_media(src))
            except Exception as ex:return self.answer(500,{'error':'Import Mac : '+str(ex)})
        if route=='/api/upload':
            name=unquote(self.headers.get('X-Filename','image.jpg'))
            ext=Path(name).suffix.lower()
            if ext not in VALID_EXTENSIONS: return self.answer(400,{'error':'Utilise un RAW CR3 ou une image JPG, PNG ou WebP.'})
            if not raw: return self.answer(400,{'error':'Fichier vide'})
            try: return self.answer(200,store_media(raw,ext,Path(name).name))
            except (ValueError,OSError) as ex:return self.answer(400,{'error':str(ex)})
        self.answer(404,{'error':'Route inconnue'})


    def manage_update(self, route, raw):
        try:
            if route=='/api/update/choose-old':
                if sys.platform!='darwin':return self.answer(400,{'error':'Sélection de dossier disponible sur Mac uniquement.'})
                try:
                    p=subprocess.run(['osascript','-e','POSIX path of (choose folder with prompt "Choisir le dossier de l’ancienne version de Studio Portra")'],capture_output=True,text=True,timeout=120)
                    if p.returncode or not p.stdout.strip():return self.answer(400,{'error':'Sélection annulée'})
                    return self.answer(200,{'path':p.stdout.strip()})
                except Exception as ex:return self.answer(500,{'error':str(ex)})
            if route == '/api/update/source':
                data=json.loads(raw)
                src=str(data.get('source') or '').strip()
                if src:releases.safe_https_url(src)
                save_update_preferences({**update_preferences(),'source':src})
                return self.answer(200,{'ok':True,'source':src})
            if route == '/api/update/preferences':
                data=json.loads(raw)
                preferences={**update_preferences(),'automatic':bool(data.get('automatic',True))}
                save_update_preferences(preferences)
                return self.answer(200,{'ok':True, **preferences})
            if route == '/api/update/check':
                src=update_preferences()['source']
                if not src:return self.answer(200,{'available':False,'notConfigured':True,
                    'message':'Publication automatique non configurée : ajoute une adresse HTTPS de confiance dans les réglages.'})
                return self.answer(200,releases.get_remote_manifest(src, APP_VERSION))
            if route in ('/api/update/install-file','/api/update/install-remote','/api/update/install-picked'):
                if not UPDATE_LOCK.acquire(blocking=False):
                    return self.answer(409,{'error':'Une mise à jour est déjà en cours.'})
                try:
                    if route.endswith('remote'):
                        src=update_preferences()['source']
                        if not src:raise releases.UpdateError('Aucune source de mises à jour configurée.')
                        info=releases.get_remote_manifest(src, APP_VERSION)
                        if not info['available']:
                            raise releases.UpdateError('Aucune version plus récente.')
                        package=releases.download(info['downloadUrl'], releases.MAX_ARCHIVE)
                        if hashlib.sha256(package).hexdigest()!=info['sha256']:
                            raise releases.UpdateError('Empreinte de téléchargement incorrecte. Mise à jour refusée.')
                    elif route.endswith('picked'):
                        if sys.platform!='darwin':raise releases.UpdateError('Cette sélection est réservée à macOS.')
                        selected=subprocess.run(['osascript','-e','POSIX path of (choose file with prompt "Choisir le ZIP de Studio Portra" of type {"public.zip-archive"})'],capture_output=True,text=True,timeout=120)
                        if selected.returncode or not selected.stdout.strip():raise releases.UpdateError('Sélection annulée')
                        path=Path(selected.stdout.strip()).expanduser().resolve()
                        if not path.is_file() or path.suffix.lower()!='.zip' or path.stat().st_size>releases.MAX_ARCHIVE:raise releases.UpdateError('ZIP invalide ou trop volumineux.')
                        package=path.read_bytes()
                    else:package=raw
                    result=releases.install_update(package, ROOT, DATA, APP_VERSION)
                    self.answer(200,result)
                    threading.Thread(target=restart_after_update,daemon=True).start()
                    return
                finally:UPDATE_LOCK.release()
            if route=='/api/update/import-old':
                data=json.loads(raw)
                path=Path(str(data.get('path') or '')).expanduser().resolve()
                old=path/'mes-donnees' if (path/'mes-donnees').is_dir() else path
                old_project=old/'projet.json'
                if not old_project.is_file() or old.resolve()==DATA.resolve():
                    raise releases.UpdateError('Choisis le dossier Studio Portra V3 contenant « mes-donnees ».')
                incoming=json.loads(old_project.read_text(encoding='utf-8'))
                if not isinstance(incoming,dict) or not isinstance(incoming.get('setups'),list) or not incoming['setups']:
                    raise releases.UpdateError('Les essais de cette ancienne version sont illisibles.')
                with LOCK:
                    stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
                    backup=DATA.parent/('sauvegarde-avant-import-'+stamp)
                    if backup.exists():backup=DATA.parent/('sauvegarde-avant-import-'+stamp+'-'+uuid.uuid4().hex[:6])
                    shutil.copytree(DATA,backup)
                    old_uploads=old/'photos-importees'
                    if old_uploads.exists():
                        for item in old_uploads.iterdir():
                            if item.is_file() and item.suffix.lower() in VALID_EXTENSIONS:
                                target=UPLOADS/item.name
                                if target.exists() and target.read_bytes()!=item.read_bytes():
                                    raise releases.UpdateError('Un nom de photo est déjà utilisé. Aucun projet remplacé.')
                        for item in old_uploads.iterdir():
                            if item.is_file() and item.suffix.lower() in VALID_EXTENSIONS:
                                shutil.copy2(item, UPLOADS/item.name)
                    write_state(incoming)
                return self.answer(200,{'ok':True,'setups':len(incoming['setups']),'backup':str(backup)})
        except (releases.UpdateError, ValueError, KeyError, OSError) as ex:
            return self.answer(400,{'error':str(ex)})
        except Exception as ex:
            return self.answer(500,{'error':'Erreur de mise à jour : '+str(ex)})
        return self.answer(404,{'error':'Action inconnue'})


def main():
    global SERVER_PORT
    port=int(os.environ.pop('STUDIO_PORTRA_PORT','0'))
    restarted=os.environ.pop('STUDIO_PORTRA_RESTART','0') == '1'
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    port=server.server_address[1]
    SERVER_PORT=port
    url=f'http://127.0.0.1:{port}/'
    print('\nSTUDIO PORTRA — ton carnet de lumière')
    print('Ouverture locale :',url)
    print('Tes données sont enregistrées dans :',DATA)
    print('Version :',APP_VERSION)
    print('Pour arrêter, ferme cette fenêtre ou appuie sur Ctrl+C.\n')
    if not restarted and os.environ.get('STUDIO_PORTRA_NO_BROWSER')!='1':
        threading.Timer(0.7,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
