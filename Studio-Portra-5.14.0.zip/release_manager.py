"""Studio Portra: safe, local file-based updater.

Only accepts versioned app ZIPs with an integrity manifest. Remote releases must
come from a user-configured HTTPS manifest, whose SHA256 pins the ZIP.
"""
from __future__ import annotations

import ast
import hashlib
import io
import json
import os
import re
import shutil
import tempfile
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

APP_ID = 'studio-portra'
FILES_ALLOWED = {'index.html', 'server.py', 'release_manager.py', 'LISEZ-MOI.txt', 'Démarrer Studio Portra.command'}
REQUIRED = {'index.html', 'server.py', 'release_manager.py'}
VERSION_RE = re.compile(r'^\d+\.\d+\.\d+$')
MAX_ARCHIVE = 25 * 1024 * 1024
MAX_MANIFEST = 96 * 1024

class UpdateError(Exception):
    pass


def version_number(s):
    if not isinstance(s, str) or not VERSION_RE.fullmatch(s):
        raise UpdateError('Numéro de version non valide (ex. 4.1.0).')
    return tuple(map(int, s.split('.')))


def current_version(root):
    try:
        d = json.loads((Path(root) / 'version.json').read_text(encoding='utf-8'))
        return d['version']
    except (OSError, ValueError, KeyError):
        return '4.0.0'


def safe_https_url(url):
    from ipaddress import ip_address
    p = urlsplit(url)
    if p.scheme != 'https' or not p.hostname or p.username or p.password or p.fragment:
        raise UpdateError('Seules les adresses HTTPS publiques sont acceptées.')
    host = p.hostname.lower()
    if host == 'localhost' or host.endswith(('.local', '.internal')):
        raise UpdateError('Adresse locale non autorisée comme source de mises à jour.')
    try:
        ip_address(host)
        raise UpdateError('Utilise un nom de domaine HTTPS, pas une adresse IP.')
    except ValueError:
        pass
    return url


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise UpdateError('Redirection refusée : vérifie les URL HTTPS de publication.')


def download(url, limit):
    safe_https_url(url)
    opener = urllib.request.build_opener(NoRedirect())
    try:
        with opener.open(urllib.request.Request(url, headers={'User-Agent': 'StudioPortra/4 updater'}), timeout=12) as res:
            data = res.read(limit + 1)
    except Exception as ex:
        raise UpdateError('Impossible de télécharger la mise à jour : ' + str(ex)) from ex
    if len(data) > limit:
        raise UpdateError('Fichier de mise à jour trop volumineux.')
    return data


def get_remote_manifest(url, installed):
    raw = download(url, MAX_MANIFEST)
    try:
        data = json.loads(raw)
        if data['app'] != APP_ID:
            raise UpdateError('Ce manifeste ne concerne pas Studio Portra.')
        ver = data['version']
        version_number(ver)
        remote_url = safe_https_url(data['downloadUrl'])
        if urlsplit(remote_url).hostname.lower() != urlsplit(url).hostname.lower():
            raise UpdateError('Le fichier doit être publié sur le même domaine HTTPS que le manifeste.')
        digest = data['sha256'].lower()
        if not re.fullmatch(r'[a-f0-9]{64}', digest):
            raise UpdateError('Empreinte SHA256 absente ou incorrecte.')
        notes = str(data.get('notes') or '')[:1200]
    except (KeyError, TypeError, ValueError) as ex:
        raise UpdateError('Fichier manifeste de publication incorrect.') from ex
    return {'version': ver, 'available': version_number(ver) > version_number(installed),
            'notes': notes, 'downloadUrl': remote_url, 'sha256': digest}


def validate_bundle(raw, installed):
    if not raw or len(raw) > MAX_ARCHIVE:
        raise UpdateError('Archive ZIP vide ou supérieure à 25 Mo.')
    try:
        z = zipfile.ZipFile(io.BytesIO(raw))
    except (OSError, zipfile.BadZipFile) as ex:
        raise UpdateError('Fichier ZIP invalide.') from ex
    with z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        if len(set(names)) != len(names):
            raise UpdateError('Le ZIP contient des fichiers en double.')
        if not set(names).issubset(FILES_ALLOWED | {'version.json'}):
            raise UpdateError('Contenu ZIP non reconnu : seuls les fichiers de Studio Portra sont autorisés.')
        if not REQUIRED.issubset(names) or 'version.json' not in names:
            raise UpdateError('Il manque des fichiers indispensables dans la mise à jour.')
        if any(i.is_dir() or (i.external_attr >> 16) & 0o170000 == 0o120000 for i in infos):
            raise UpdateError('Liens symboliques et répertoires non autorisés.')
        if any(i.file_size > 15 * 1024 * 1024 for i in infos):
            raise UpdateError('Un fichier du ZIP dépasse 15 Mo.')
        try:
            v = json.loads(z.read('version.json'))
        except (ValueError, KeyError) as ex:
            raise UpdateError('version.json est illisible.') from ex
        if v.get('app') != APP_ID:
            raise UpdateError('Cette mise à jour n’est pas celle de Studio Portra.')
        version = v.get('version')
        if version_number(version) <= version_number(installed):
            raise UpdateError('La mise à jour doit être plus récente que la version installée.')
        expected = v.get('files')
        if not isinstance(expected, dict) or set(expected) != (set(names) - {'version.json'}):
            raise UpdateError('Liste de fichiers incohérente dans version.json.')
        files = {}
        for filename in sorted(expected):
            value = z.read(filename)
            if hashlib.sha256(value).hexdigest() != expected[filename]:
                raise UpdateError(f'Empreinte incorrecte : {filename}.')
            files[filename] = value
        for filename in ('server.py', 'release_manager.py'):
            try:
                ast.parse(files[filename].decode('utf-8'))
            except (UnicodeError, SyntaxError) as ex:
                raise UpdateError(f'Code de mise à jour invalide : {filename}.') from ex
        if not files['index.html'].strip().startswith(b'<!DOCTYPE html>'):
            raise UpdateError('Interface de mise à jour invalide.')
        return version, files, z.read('version.json')


def install_update(raw, root, data, installed):
    root = Path(root)
    data = Path(data)
    version, files, manifest = validate_bundle(raw, installed)
    backup_dir = data / 'sauvegardes-versions' / (datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + installed.replace('.', '-'))
    staging = Path(tempfile.mkdtemp(prefix='.studio-portra-update-', dir=root))
    originals = {}
    changed = []
    try:
        # First stage everything and validate write permissions before touching running code.
        for name, contents in {**files, 'version.json': manifest}.items():
            dest = staging / name
            dest.write_bytes(contents)
        backup_dir.mkdir(parents=True, exist_ok=False)
        for name in [*files, 'version.json']:
            target = root / name
            if target.is_file():
                originals[name] = target.read_bytes()
                (backup_dir / name).write_bytes(originals[name])
        try:
            # Commit metadata last so a failed update never reports a new version.
            for name in [*sorted(files), 'version.json']:
                incoming = staging / name
                target = root / name
                mode = target.stat().st_mode if target.exists() else 0o644
                os.replace(incoming, target)
                if name.endswith('.command'):
                    target.chmod(0o755)
                else:
                    target.chmod(mode & 0o777)
                changed.append(name)
        except Exception:
            for name in reversed(changed):
                target = root / name
                if name in originals:
                    target.write_bytes(originals[name])
                else:
                    target.unlink(missing_ok=True)
            raise
    except Exception as ex:
        raise UpdateError('Mise à jour non appliquée : ' + str(ex)) from ex
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    return {'installed': version, 'previous': installed, 'backup': str(backup_dir), 'restart': True}


def make_version_manifest(root, version):
    root=Path(root)
    files = {}
    for name in sorted(FILES_ALLOWED):
        path = root / name
        if path.is_file():
            files[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {'app': APP_ID, 'version': version, 'files': files}
